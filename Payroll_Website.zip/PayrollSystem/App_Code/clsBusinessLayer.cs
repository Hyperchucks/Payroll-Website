﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// This namespace contains classes that will be use to send mail
// to the SMTP server.
using System.Net.Mail;

/// <summary>
// Set up the email set up for sending and the receiver for emails when the 
// login fails
/// </summary>
public class clsBusinessLayer
{
    
    public static bool SendEmail(string Sender, string Recipient, string bcc, string cc,
    string Subject, string Body)
    {
        try
        {
            // Instantiate a new mail message
            MailMessage MyMailMessage = new MailMessage();
            // Creates a new mail sender
            MyMailMessage.From = new MailAddress(Sender);
            // Creates a new mail receiver or recipient
            MyMailMessage.To.Add(new MailAddress(Recipient));
            // This checks if the blind copy collection is not empty or null.
            if (bcc != null && bcc != string.Empty)
            {
                // Creates blind copy collection if the field is not empty or null.
                MyMailMessage.Bcc.Add(new MailAddress(bcc));
            }
            // This checks if the copy recipient is not null or if is not empty
            if (cc != null && cc != string.Empty)
            {
                // Creates a copy colleciton if the field is not empty or null.
                MyMailMessage.CC.Add(new MailAddress(cc));
            }
            // Creates a subject string for the mail
            MyMailMessage.Subject = Subject;
            // Creates the body string for the mail
            MyMailMessage.Body = Body;
            // Sets the value that the mail message body is in html format.
            MyMailMessage.IsBodyHtml = true;
            // Sets the priority of the mail being sent.
            MyMailMessage.Priority = MailPriority.Normal;
            // Instantiate a new SMTP client that can send the mail as "localhost".
            SmtpClient MySmtpClient = new SmtpClient("localhost");
            //SMTP Port = 25;
            //Generic IP host = "127.0.0.1";
            // Sets the client to send the message with the MyMailMessage values.
            MySmtpClient.Send(MyMailMessage);
            // Returns the values if the requirements are met.
            return true;
        }
        catch (Exception ex)
        {
            // Returns false if the requirements are not met.
            return false;
        }
    }

    public clsBusinessLayer()
    {
        
    }
}