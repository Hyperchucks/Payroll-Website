﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        // Local variable for dsUser.
        dsUser dsUserLogin;
        // Local variable for the security level.
        string SecurityLevel;
        // Verify the connection to the local connection to the database on the wesite folder.
        dsUserLogin = clsDataLayer.VerifyUser(Server.MapPath("PayrollSystem_DB.accdb"),
        Login1.UserName, Login1.Password);
        // This check if we have a match witht he user login information ont he 
        // dataset otherwise it will be false if there is not match and login fail.
        if (dsUserLogin.tblUserLogin.Count < 1)
        {
            e.Authenticated = false;
            // Checks if the class clsBusinessLayer has a sender, recipient and credentials used to
            // login.
            // If it does it send a text to the recipient with the fail login information.
            if (clsBusinessLayer.SendEmail("gaming_marrero@yahoo.com",
            "marrero_tony@yahoo.com", "", "", "Login Incorrect",
            "The login failed for UserName: " + Login1.UserName +
            " Password: " + Login1.Password))
            {
                Login1.FailureText = Login1.FailureText +
                " Your incorrect login information was sent to marrero_tony@yahoo.com";
            }
            return;
        }
        // It gets the security level from the tblUserLogin table on the dataset.
        SecurityLevel = dsUserLogin.tblUserLogin[0].SecurityLevel.ToString();
        // It checks for what security level is retrieved from the table.
        switch (SecurityLevel)
        {
            case "A":
                // It will check if the security level is A on the table and assign a session A to the security level.
                e.Authenticated = true;
                FormsAuthentication.RedirectFromLoginPage(Login1.UserName, false);
                Session["SecurityLevel"] = "A";
                break;
            case "U":
                // It will check if the security level is U on the table and assign a session U to the security level.
                // If it doesn't find a A or U it ill fail the login authentication.
                e.Authenticated = true;
                FormsAuthentication.RedirectFromLoginPage(Login1.UserName, false);
                Session["SecurityLevel"] = "U";
                break;
            default:
                e.Authenticated = false;
                break;
        }
    }
}